﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tyuiu.TaturinAM.Sprint5.Review.TaskReview.V4.Lib;
namespace Tyuiu.TaturinAM.Sprint5.Review.TaskReview.V4
{
    class Program
    {
        static void Main(string[] args)
        {
            DataService ds = new DataService();
            Console.Title = "Спринт #5 | Выполнил: Татурин А. М. | СМАРТб-23-1";
            Console.WriteLine("*********************************************************************************");
            Console.WriteLine("* Спринт #5                                                                     *");
            Console.WriteLine("* Тема: SprintReview                                                            *");
            Console.WriteLine("* Задание #7                                                                    *");
            Console.WriteLine("* Вариант #4                                                                    *");
            Console.WriteLine("* Выполнила Татурин Артем Максимвочи | СМАРТб-23-1                              *");
            Console.WriteLine("*********************************************************************************");
            Console.WriteLine("* УСЛОВИЕ:                                                                      *");
            Console.WriteLine("* Дан файл в котором есть набор символьных данных. Заменить все русские буквы   *");
            Console.WriteLine("* на #. Полученный результат сохранить в файл OutPutDataFileTask7V4.txt.         ");
            Console.WriteLine("*********************************************************************************");
            Console.WriteLine("* ИСХОДНЫЕ ДАННЫЕ:                                                              *");
            Console.WriteLine("*********************************************************************************");
            string path = @"C:\Users\Tatur\source\repos\Tyuiu.TaturinAM.Sprint5.Review\InPutDataFileTask7V4.txt";
            string pathSave = @"C:\Users\Tatur\source\repos\Tyuiu.TaturinAM.Sprint5.Review\Tyuiu.TaturinAM.Sprint5.Review.TaskReview.V4\bin\Debug\OutPutDataFileTask7V4.txt";
            Console.WriteLine("Данные из файла: " + path);
            Console.WriteLine("*********************************************************************************");
            Console.WriteLine("* РЕЗУЛЬТАТ:                                                                    *");
            Console.WriteLine("*********************************************************************************");
            pathSave = ds.LoadDataAndSave(path);
            Console.WriteLine(pathSave);
            Console.ReadKey();
        }
    }
}

