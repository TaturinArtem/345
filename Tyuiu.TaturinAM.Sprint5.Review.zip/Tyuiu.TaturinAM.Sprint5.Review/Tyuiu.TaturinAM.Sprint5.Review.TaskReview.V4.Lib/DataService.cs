﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using tyuiu.cources.programming.interfaces.Sprint5;
namespace Tyuiu.TaturinAM.Sprint5.Review.TaskReview.V4.Lib
{
    public class DataService : ISprint5Task7V4
    {
        public string LoadDataAndSave(string path)
        {
            string pathSave = @"C:\Users\Tatur\source\repos\Tyuiu.TaturinAM.Sprint5.Review\Tyuiu.TaturinAM.Sprint5.Review.TaskReview.V4\bin\Debug\OutPutDataFileTask7V4.txt";
            FileInfo fileinfo = new FileInfo(pathSave);
            bool exists = fileinfo.Exists;
            string text = File.ReadAllText(path);
            char[] res = new char[text.Length];
            for (int i = 0; i < text.Length; i++)
            {
                char sym = text[i];
                if ((sym >= 'А' && sym <= 'Я') || (sym >= 'а' && sym <= 'я'))
                {
                    res[i] = '#';
                }
                else
                {
                    res[i] = sym;
                }
            }
            using (StreamWriter writer = new StreamWriter(pathSave))
            {
                writer.Write(res);
            }
            return pathSave;
        }
    }
}